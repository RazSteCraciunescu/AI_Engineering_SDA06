# python project for scrapping sda learnify
# install python & dependencies
# setup gemini api key
# run in terminal: py {{ fileName }}
